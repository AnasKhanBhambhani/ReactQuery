import { Link } from 'react-router-dom';
import './app.css'

function App() {
    return (
        <>
            <h1 className='bg-orange-300'>The Awesome React query</h1>
            <div>
                <Link to="/">Home</Link> <br />
                <Link to="/products">Products</Link>
            </div>
        </>
    );
}

export default App;
