import { useMutation, useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { useParams } from 'react-router-dom';
const Product = () => {
    const params = useParams();
    const mutation = useMutation({
        mutationFn: (newProduct) => {
            return axios.put(`https://dummyjson.com/products/${params.productId}`, newProduct)
        }
    })
    const fetchProduct = async () => {
        const response = await fetch(`https://dummyjson.com/products/${params.productId}`);
        if (!response.ok) {
            throw new Error('your network issue occur.....');
        }
        const data = await response.json();
        return data;
    }
    const {
        isLoading,
        error,
        data: product
    } = useQuery({
        queryKey: ["product", params.productId],
        queryFn: fetchProduct,
        // staleTime:10000
    });
    {
        if (isLoading) {
            return <h1>Loading......</h1>
        }
    }
    {
        if (error) {
            return <h1>Error: {error.message}</h1>
        }
    }
    return (
        <>
            <div>Product:{product.title}</div>
            <button
                onClick={() => {
                    mutation.mutate({ title: 'udpated product...' })
                }} className='bg-blue-400 px-4 py-2 rounded'>udpate your product
            </button>
        </>

    )

};

export default Product;
